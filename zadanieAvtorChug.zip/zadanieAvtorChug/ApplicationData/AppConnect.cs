﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadanieAvtorChug.ApplicationData
{
    class AppConnect
    {
        public static Nikita_ChugunovEntities modelOdb;
    }
}
