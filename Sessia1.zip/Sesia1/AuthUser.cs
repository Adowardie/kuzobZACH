﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Sesia1
{
    public static class AuthUser
    {
        public static Data.autoriz autoriz { get; set; }
        public static Frame MainFrame { get; set; }
    }
}
